/**
 * EYE DEPARTMENT CHECKLIST / THEATRE LIST — SHARED BACKEND
 * ---------------------------------------------------------
 * HOW TO INSTALL
 * 1. Create a new Google Sheet in your departmental Drive folder
 *    (this Sheet becomes the shared database — don't put anything
 *    else in it).
 * 2. Extensions > Apps Script. Delete the sample code and paste
 *    this whole file in.
 * 3. Deploy > New deployment > select type "Web app".
 *      - Execute as: Me
 *      - Who has access: "Anyone within [your organization]" is
 *        strongly recommended, since this handles patient health
 *        data (names, diagnoses, HIV/serology status). Avoid
 *        "Anyone" unless you specifically intend this to be public.
 * 4. Copy the Web App URL you're given and paste it into
 *    API_URL in api.js in the React app.
 * 5. Re-run "Deploy > Manage deployments > Edit > New version"
 *    any time you change this file, or the app will keep hitting
 *    the old code.
 *
 * KEEPING RECORDS IN SYNC WITH YOUR LIVE PATIENT LIST
 * If you already maintain your patient list in a Google Sheet
 * (separate from this backend Sheet), set SOURCE_SHEET_ID below to
 * that Sheet's ID (the long string in its URL between /d/ and
 * /edit) and this script will pull from it directly — no exporting
 * to Excel and re-uploading needed. Then either:
 *   a) Click "Sync from Google Sheet" in the app whenever you want
 *      the latest data, or
 *   b) Set up a time-driven trigger (Triggers, clock icon, on the
 *      left of the Apps Script editor > Add Trigger > choose
 *      syncFromSourceSheet > Time-driven > e.g. every 15 minutes)
 *      so it updates automatically with no one needing to click
 *      anything.
 * The source Sheet must be shared with (or owned by) the same
 * Google account that deployed this script ("Execute as: Me").
 * Its first row must be column headers matching the field names
 * this app expects (Name, Age, Sex, UMID Number, etc.) — the same
 * headers your Excel exports already use.
 *
 * Three tabs are created automatically the first time each is used:
 *   Records      | patientId | recordJson    | updatedAt
 *   Checklists   | patientId | checklistJson | completed | updatedAt
 *   TheatreLists | date      | listJson      | updatedAt
 *
 * Each row stores one patient/list as a JSON blob rather than one
 * spreadsheet column per field — this keeps the backend working
 * no matter what columns your Excel upload contains, and keeps
 * this script simple to maintain.
 */

const SOURCE_SHEET_ID = 'PASTE_YOUR_LIVE_PATIENT_LIST_SHEET_ID_HERE'

function doGet(e) {
  try {
    var action = e.parameter.action

    if (action === 'getRecords') {
      return respond({ records: getAllRecords() })
    }

    if (action === 'getCompletedRecords') {
      return respond({ completed: getCompletedMap() })
    }

    if (action === 'getCaseSheet') {
      return respond({ caseSheet: getCaseSheet(e.parameter.patientId) })
    }

    if (action === 'getChecklist') {
      return respond({ checklist: getChecklist(e.parameter.patientId) })
    }

    if (action === 'getTheatreList') {
      return respond({ list: getTheatreList(e.parameter.date) })
    }

    return respond({ error: 'Unknown action: ' + action })
  } catch (err) {
    return respond({ error: String(err) })
  }
}

function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents)
    var action = body.action
    var payload = body.payload || {}

    if (action === 'uploadRecords') {
      uploadRecords(payload.records || [])
      return respond({ success: true, count: (payload.records || []).length })
    }

    if (action === 'saveCaseSheet') {
      saveCaseSheet(payload.patientId, payload.caseSheet)
      return respond({ success: true })
    }

    if (action === 'saveChecklist') {
      saveChecklist(payload.patientId, payload.checklist)
      return respond({ success: true })
    }

    if (action === 'saveTheatreList') {
      saveTheatreList(payload.date, payload.list || [])
      return respond({ success: true })
    }

    if (action === 'syncFromSource') {
      var count = syncFromSourceSheet()
      return respond({ success: true, count: count })
    }

    return respond({ error: 'Unknown action: ' + action })
  } catch (err) {
    return respond({ error: String(err) })
  }
}

function respond(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON)
}

/* ---------- sheet helpers ---------- */

function getSheet(name, headers) {
  var ss = SpreadsheetApp.getActiveSpreadsheet()
  var sheet = ss.getSheetByName(name)

  if (!sheet) {
    sheet = ss.insertSheet(name)
    sheet.appendRow(headers)
    sheet.setFrozenRows(1)
  }

  return sheet
}

/* ---------- Records ---------- */

function getRecordsSheet() {
  return getSheet('Records', ['patientId', 'recordJson', 'updatedAt'])
}

function getAllRecords() {
  var sheet = getRecordsSheet()
  var data = sheet.getDataRange().getValues()
  var records = []

  for (var i = 1; i < data.length; i++) {
    var json = data[i][1]
    if (json) {
      try {
        records.push(JSON.parse(json))
      } catch (parseErr) {
        // skip a corrupted row rather than fail the whole request
      }
    }
  }

  return records
}

function uploadRecords(records) {
  var sheet = getRecordsSheet()

  // A fresh Excel upload replaces the whole shared list.
  var lastRow = sheet.getLastRow()
  if (lastRow > 1) {
    sheet.getRange(2, 1, lastRow - 1, 3).clearContent()
  }

  var now = new Date().toISOString()
  var rows = records.map(function (record) {
    var patientId = computePatientId(record)
    return [patientId, JSON.stringify(record), now]
  })

  if (rows.length > 0) {
    sheet.getRange(2, 1, rows.length, 3).setValues(rows)
  }
}

function computePatientId(record) {
  var keys = Object.keys(record)

  function find(name) {
    var key = keys.find(function (k) {
      return k.trim().toLowerCase() === name.trim().toLowerCase()
    })
    return key ? record[key] : ''
  }

  return find('UMID Number') || find('CR Number') || find('Name')
}

/* ---------- Sync from a live source Sheet ---------- */

function syncFromSourceSheet() {
  if (!SOURCE_SHEET_ID || SOURCE_SHEET_ID.indexOf('PASTE_') === 0) {
    throw new Error(
      'SOURCE_SHEET_ID isn\'t set yet — paste your patient list Sheet\'s ID at the top of Code.gs first.'
    )
  }

  var sourceSpreadsheet = SpreadsheetApp.openById(SOURCE_SHEET_ID)
  var sourceSheet = sourceSpreadsheet.getSheets()[0]
  var data = sourceSheet.getDataRange().getValues()

  if (data.length < 2) {
    uploadRecords([])
    return 0
  }

  var headers = data[0]
  var records = []

  for (var i = 1; i < data.length; i++) {
    var row = data[i]
    var record = {}
    var hasValue = false

    for (var j = 0; j < headers.length; j++) {
      var header = headers[j]
      if (!header) continue

      var cell = row[j]

      // Dates become plain yyyy-MM-dd text (in the script's time zone) so
      // they don't shift by a day when sent to the app.
      if (cell instanceof Date) {
        cell = Utilities.formatDate(cell, Session.getScriptTimeZone(), 'yyyy-MM-dd')
      }

      record[header] = cell

      if (cell !== '' && cell !== null && cell !== undefined) {
        hasValue = true
      }
    }

    if (hasValue) {
      records.push(record)
    }
  }

  uploadRecords(records)
  return records.length
}

/* ---------- Checklists ---------- */

function getChecklistsSheet() {
  return getSheet('Checklists', ['patientId', 'checklistJson', 'completed', 'updatedAt'])
}

function getChecklist(patientId) {
  var sheet = getChecklistsSheet()
  var data = sheet.getDataRange().getValues()

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(patientId)) {
      try {
        return JSON.parse(data[i][1])
      } catch (parseErr) {
        return null
      }
    }
  }

  return null
}

function getCompletedMap() {
  var sheet = getChecklistsSheet()
  var data = sheet.getDataRange().getValues()
  var map = {}

  for (var i = 1; i < data.length; i++) {
    if (data[i][2] === true || data[i][2] === 'TRUE') {
      map[data[i][0]] = true
    }
  }

  return map
}

function saveChecklist(patientId, checklist) {
  var sheet = getChecklistsSheet()
  var data = sheet.getDataRange().getValues()
  var now = new Date().toISOString()

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(patientId)) {
      sheet.getRange(i + 1, 2, 1, 3).setValues([[JSON.stringify(checklist), true, now]])
      return
    }
  }

  sheet.appendRow([patientId, JSON.stringify(checklist), true, now])
}

/* ---------- Theatre Lists ---------- */

function getTheatreListsSheet() {
  return getSheet('TheatreLists', ['date', 'listJson', 'updatedAt'])
}

function getTheatreList(date) {
  var sheet = getTheatreListsSheet()
  var data = sheet.getDataRange().getValues()

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(date)) {
      try {
        return JSON.parse(data[i][1])
      } catch (parseErr) {
        return []
      }
    }
  }

  return []
}

function saveTheatreList(date, list) {
  var sheet = getTheatreListsSheet()
  var data = sheet.getDataRange().getValues()
  var now = new Date().toISOString()

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(date)) {
      sheet.getRange(i + 1, 2, 1, 2).setValues([[JSON.stringify(list), now]])
      return
    }
  }

  sheet.appendRow([date, JSON.stringify(list), now])
}

/* ---------- Case Sheets ---------- */

function getCaseSheetsSheet() {
  return getSheet('CaseSheets', ['patientId', 'caseSheetJson', 'updatedAt'])
}

function getCaseSheet(patientId) {
  var sheet = getCaseSheetsSheet()
  var data = sheet.getDataRange().getValues()

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(patientId)) {
      try {
        return JSON.parse(data[i][1])
      } catch (parseErr) {
        return null
      }
    }
  }

  return null
}

function saveCaseSheet(patientId, caseSheet) {
  var sheet = getCaseSheetsSheet()
  var data = sheet.getDataRange().getValues()
  var now = new Date().toISOString()

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(patientId)) {
      sheet.getRange(i + 1, 2, 1, 2).setValues([[JSON.stringify(caseSheet), now]])
      return
    }
  }

  sheet.appendRow([patientId, JSON.stringify(caseSheet), now])
}
